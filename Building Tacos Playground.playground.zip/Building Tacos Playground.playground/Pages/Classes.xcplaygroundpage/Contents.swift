//: # Let's Build Tacos!!
//: ![UML for a Shell](ShellUML.png)
//create your shell class here.


//: ![UML for a Meat](MeatUML.png)
//create your meat class here


//: ![UML for a Vegetable](VegetableUML.png)
//create your vegetable class here


//: ![UML for Cheese](CheeseUML.png)
//create your cheese class here



//: ## Video 2 - The Taco Class
//: ![UML for Taco](TacoUML.png)
//create your taco class here.


//: ## Video 3 - Instantiating all the components
//Instantiate your components here


//: ## Video 4 - Create the Magnificent Taco
//Mmmmmm. Tacos


